#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/wait.h>

#define FIFO_NAME "/tmp/myfifo"
#define BUFFER_SIZE 256

void writer_process() {
    int fd;
    char buffer[BUFFER_SIZE];
    
    printf("写者进程启动 (PID: %d)\n", getpid());
    
    fd = open(FIFO_NAME, O_WRONLY);
    if (fd == -1) {
        perror("写者打开管道失败");
        exit(1);
    }
    
    char *messages[] = {
        "第一条消息：Hello from writer!",
        "第二条消息：命名管道通信测试",
        "第三条消息：进程间通信成功！",
        "END"
    };
    
    for (int i = 0; i < 4; i++) {
        printf("写者发送: %s\n", messages[i]);
        write(fd, messages[i], strlen(messages[i]) + 1);
        sleep(1);
    }
    
    close(fd);
    printf("写者进程结束\n");
}

void reader_process() {
    int fd;
    char buffer[BUFFER_SIZE];
    int bytes_read;
    
    printf("读者进程启动 (PID: %d)\n", getpid());
    
    fd = open(FIFO_NAME, O_RDONLY);
    if (fd == -1) {
        perror("读者打开管道失败");
        exit(1);
    }
    
    while (1) {
        bytes_read = read(fd, buffer, BUFFER_SIZE);
        if (bytes_read > 0) {
            printf("读者接收: %s\n", buffer);
            
            if (strcmp(buffer, "END") == 0) {
                break;
            }
        }
    }
    
    close(fd);
    printf("读者进程结束\n");
}

void named_pipe(){
    pid_t pid1, pid2;
    
    printf("=== 命名管道通信示例 ===\n");
    
    if (access(FIFO_NAME, F_OK) == -1) {
        if (mkfifo(FIFO_NAME, 0666) == -1) {
            perror("命名管道创建失败");
            exit(1);
        }
        printf("命名管道创建成功: %s\n", FIFO_NAME);
    } else {
        printf("命名管道已存在: %s\n", FIFO_NAME);
    }
    
    pid1 = fork();
    if (pid1 == 0) {
        writer_process();
        exit(0);
    }
    
    pid2 = fork();
    if (pid2 == 0) {
        reader_process();
        exit(0);
    }
    
    wait(NULL);
    wait(NULL);
    
    unlink(FIFO_NAME);
    printf("命名管道已删除\n");
    printf("主进程结束\n");
}

void unnamed_pipe(){
    int pipe_fd[2];
    pid_t pid;
    char buffer[BUFFER_SIZE];
    int bytes_read;
    
    printf("=== 无名管道通信示例 ===\n");
    printf("父进程PID: %d\n", getpid());
    
    if (pipe(pipe_fd) == -1) {
        perror("管道创建失败");
        exit(1);
    }
    
    printf("管道创建成功: 读端=%d, 写端=%d\n", pipe_fd[0], pipe_fd[1]);
    
    pid = fork();
    
    if (pid == -1) {
        perror("fork失败");
        exit(1);
    }
    
    if (pid == 0) {
        printf("子进程启动 (PID: %d)\n", getpid());
        
        close(pipe_fd[0]);

        lockf(pipe_fd[1], F_LOCK, 0);
        
        char message[] = "Hello from child process! 这是子进程通过管道发送的消息。";
        write(pipe_fd[1], message, strlen(message) + 1);
        printf("子进程写入数据: %s\n", message);
        
        lockf(pipe_fd[1], F_ULOCK, 0);
        
        sleep(1);
        char message2[] = "这是子进程的第二条消息！";
        write(pipe_fd[1], message2, strlen(message2) + 1);
        printf("子进程写入第二条数据: %s\n", message2);
        
        close(pipe_fd[1]);
        printf("子进程结束\n");
        exit(0);
        
    } else {
        printf("父进程等待子进程数据...\n");
        
        close(pipe_fd[1]);
        
        while ((bytes_read = read(pipe_fd[0], buffer, BUFFER_SIZE)) > 0) {
            printf("父进程接收到数据: %s\n", buffer);
            printf("接收字节数: %d\n", bytes_read);
        }
        
        wait(NULL);
        
        close(pipe_fd[0]);
        printf("父进程结束\n");
    }
}

int main() {
    named_pipe();
    sleep(1);
    unnamed_pipe();
    return 0;
}