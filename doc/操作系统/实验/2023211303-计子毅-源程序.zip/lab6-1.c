#include <stdio.h>
#include <unistd.h>

void get_cpu_info() {
    printf("=== CPU信息检测 ===\n");
    
    FILE *fp = popen("grep 'physical id' /proc/cpuinfo | sort | uniq | wc -l", "r");
    char physical_cpu[10];
    fgets(physical_cpu, sizeof(physical_cpu), fp);
    pclose(fp);
    printf("物理CPU数量: %s", physical_cpu);
    
    fp = popen("grep 'cpu cores' /proc/cpuinfo | uniq | awk -F: '{print $2}'", "r");
    char cpu_cores[10];
    fgets(cpu_cores, sizeof(cpu_cores), fp);
    pclose(fp);
    printf("每个CPU的核数: %s", cpu_cores);
    
    fp = popen("cat /proc/cpuinfo | grep 'processor' | wc -l", "r");
    char logical_cpu[10];
    fgets(logical_cpu, sizeof(logical_cpu), fp);
    pclose(fp);
    printf("逻辑CPU数量: %s", logical_cpu);
    
    fp = popen("grep 'model name' /proc/cpuinfo | uniq", "r");
    char model_name[100];
    fgets(model_name, sizeof(model_name), fp);
    pclose(fp);
    printf("CPU型号: %s", model_name);
}

int main() {
    get_cpu_info();
    return 0;
}