#include<iostream>
#include<string>
#include<fstream>
#include<sstream>
using namespace std;
#define N 1000000

int partition(int* nums, int left, int right) {
	int key = nums[left];
	while (left < right) {
		if (nums[right] >= key && left < right) right--;
		nums[left] = nums[right];
		if (nums[left] <= key && left < right) left++;
		nums[right] = nums[left];
	}
	nums[left] = key;
	return left;
}

void quicksort(int* nums, int left, int right) {
	if (left < right) {
		int pos = partition(nums, left, right);
		quicksort(nums, left, pos - 1);
		quicksort(nums, pos + 1, right);
	}
}

int main() {
	ifstream ifs;
	ofstream ofs;
	ifs.open("quicksort.in", ios::in);
	string line;
	int n;
	int* nums = new int[N];
	getline(ifs, line);
	n = line[0] - '0';
	int a;
	istringstream iss;
	while (getline(ifs, line)) {
		iss.str(line);
		for (int i = 0; i < n; i++) {
			iss >> a;
			nums[i] = a;
		}
	}
	quicksort(nums, 0, n - 1);
	ifs.close();
	ofs.open("quicksort.out", ios::out);
	for (int i = 0; i < n; i++) {
		ofs << nums[i] << " ";
	}
	ofs << endl;
	ofs.close();
	return 0;
}