#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/time.h>

#define APPLE_MAX_VALUE 100000000

struct apple_no_optimize {
    unsigned long long a;
    unsigned long long b;
    pthread_rwlock_t rwlock;
};

struct apple_optimized {
    unsigned long long a;
    char padding1[128];
    unsigned long long b;
    char padding2[128];
    pthread_rwlock_t rwlock;
};

long long get_current_time() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (long long)tv.tv_sec * 1000000 + tv.tv_usec;
}

void* calc_apple_a_no_opt(void* arg) {
    struct apple_no_optimize* test = (struct apple_no_optimize*)arg;
    for (unsigned long long sum = 0; sum < APPLE_MAX_VALUE; sum++) {
        test->a += sum;
    }
    return NULL;
}

void* calc_apple_b_no_opt(void* arg) {
    struct apple_no_optimize* test = (struct apple_no_optimize*)arg;
    for (unsigned long long sum = 0; sum < APPLE_MAX_VALUE; sum++) {
        test->b += sum;
    }
    return NULL;
}

void* calc_apple_a_opt(void* arg) {
    struct apple_optimized* test = (struct apple_optimized*)arg;
    for (unsigned long long sum = 0; sum < APPLE_MAX_VALUE; sum++) {
        test->a += sum;
    }
    return NULL;
}

void* calc_apple_b_opt(void* arg) {
    struct apple_optimized* test = (struct apple_optimized*)arg;
    for (unsigned long long sum = 0; sum < APPLE_MAX_VALUE; sum++) {
        test->b += sum;
    }
    return NULL;
}

void* no_cache_optimize_test(void* arg) {
    struct apple_no_optimize* test = (struct apple_no_optimize*)malloc(sizeof(struct apple_no_optimize));
    test->a = 0;
    test->b = 0;
    
    pthread_t thread1, thread2;
    
    printf("开始未优化版本测试...\n");
    pthread_create(&thread1, NULL, calc_apple_a_no_opt, test);
    pthread_create(&thread2, NULL, calc_apple_b_no_opt, test);
    
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    
    printf("未优化版本结果: a=%llu, b=%llu\n", test->a, test->b);
    
    free(test);
    return NULL;
}

void* cache_optimize_test(void* arg) {
    struct apple_optimized* test = (struct apple_optimized*)malloc(sizeof(struct apple_optimized));
    test->a = 0;
    test->b = 0;
    
    pthread_t thread1, thread2;
    
    printf("开始优化版本测试...\n");
    pthread_create(&thread1, NULL, calc_apple_a_opt, test);
    pthread_create(&thread2, NULL, calc_apple_b_opt, test);
    
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    
    printf("优化版本结果: a=%llu, b=%llu\n", test->a, test->b);
    
    free(test);
    return NULL;
}

void* single_thread_baseline(void* arg) {
    struct apple_no_optimize* test = (struct apple_no_optimize*)malloc(sizeof(struct apple_no_optimize));
    test->a = 0;
    test->b = 0;
    
    printf("开始单线程基准测试...\n");
    
    for (unsigned long long sum = 0; sum < APPLE_MAX_VALUE; sum++) {
        test->a += sum;
    }
    for (unsigned long long sum = 0; sum < APPLE_MAX_VALUE; sum++) {
        test->b += sum;
    }
    
    printf("单线程结果: a=%llu, b=%llu\n", test->a, test->b);
    
    free(test);
    return NULL;
}

int compare_long_long(const void* a, const void* b) {
    long long x = *(const long long*)a;
    long long y = *(const long long*)b;
    if (x < y) return -1;
    if (x > y) return 1;
    return 0;
}

long long calculate_k_best(long long* times, int count, int k) {
    qsort(times, count, sizeof(long long), compare_long_long);
    long long sum = 0;
    for (int i = 0; i < k; i++) {
        sum += times[i];
    }
    return sum / k;
}

void run_cache_test() {
    int iterations = 5;
    
    printf("========================================\n");
    printf("        Cache优化性能测试\n");
    printf("========================================\n\n");
    
    printf("测试配置:\n");
    printf("- 循环次数: %d\n", APPLE_MAX_VALUE);
    printf("- 测试迭代: %d次\n", iterations);
    printf("- Cache行填充: 128字节\n\n");
    
    long long* single_times = (long long*)malloc(iterations * sizeof(long long));
    long long* no_opt_times = (long long*)malloc(iterations * sizeof(long long));
    long long* opt_times = (long long*)malloc(iterations * sizeof(long long));

    printf("=== 单线程基准测试 ===\n");
    for (int i = 0; i < iterations; i++) {
        long long start = get_current_time();
        single_thread_baseline(NULL);
        long long end = get_current_time();
        long long duration = end - start;
        single_times[i] = duration;
        printf("第%d次运行时间: %lld 微秒 (%.3f秒)\n", i+1, duration, duration/1000000.0);
        usleep(100000);
    }
    
    printf("\n=== 未优化版本测试（可能存在Cache伪共享） ===\n");
    for (int i = 0; i < iterations; i++) {
        long long start = get_current_time();
        no_cache_optimize_test(NULL);
        long long end = get_current_time();
        long long duration = end - start;
        no_opt_times[i] = duration;
        printf("第%d次运行时间: %lld 微秒 (%.3f秒)\n", i+1, duration, duration/1000000.0);
        usleep(100000);
    }
    
    printf("\n=== 优化版本测试（Cache行对齐） ===\n");
    for (int i = 0; i < iterations; i++) {
        long long start = get_current_time();
        cache_optimize_test(NULL);
        long long end = get_current_time();
        long long duration = end - start;
        opt_times[i] = duration;
        printf("第%d次运行时间: %lld 微秒 (%.3f秒)\n", i+1, duration, duration/1000000.0);
        usleep(100000);
    }
    
    long long avg_single = calculate_k_best(single_times, iterations, iterations);
    long long avg_no_opt = calculate_k_best(no_opt_times, iterations, iterations);
    long long avg_opt = calculate_k_best(opt_times, iterations, iterations);
    long long k_best_single = calculate_k_best(single_times, iterations, iterations > 5 ? 5 : iterations);
    long long k_best_no_opt = calculate_k_best(no_opt_times, iterations, iterations > 5 ? 5 : iterations);
    long long k_best_opt = calculate_k_best(opt_times, iterations, iterations > 5 ? 5 : iterations);
    
    printf("\n========================================\n");
    printf("           测试结果分析\n");
    printf("========================================\n");
    
    printf("平均运行时间:\n");
    printf("单线程基准:   %lld 微秒\n", avg_single);
    printf("未优化版本:   %lld 微秒\n", avg_no_opt);
    printf("优化版本:     %lld 微秒\n", avg_opt);
    
    printf("\nK最佳运行时间:\n");
    printf("单线程基准:   %lld 微秒\n", k_best_single);
    printf("未优化版本:   %lld 微秒\n", k_best_no_opt);
    printf("优化版本:     %lld 微秒\n", k_best_opt);
    
    printf("\n性能对比:\n");
    if (k_best_opt < k_best_no_opt) {
        double improvement = (1.0 - (double)k_best_opt / k_best_no_opt) * 100;
        printf("Cache优化带来性能提升: +%.2f%%\n", improvement);
    } else {
        double degradation = ((double)k_best_opt / k_best_no_opt - 1.0) * 100;
        printf("优化版本性能下降: -%.2f%%\n", degradation);
    }
    
    printf("\n相对于单线程:\n");
    double speedup_no_opt = (double)k_best_single / k_best_no_opt;
    double speedup_opt = (double)k_best_single / k_best_opt;
    printf("未优化版本并行加速比: %.2fx\n", speedup_no_opt);
    printf("优化版本并行加速比:   %.2fx\n", speedup_opt);
    
    free(single_times);
    free(no_opt_times);
    free(opt_times);
}

int main() {
    
    run_cache_test();
    
    return 0;
}