#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>

void* thread_func1(void* arg) {
    int thread_id = *(int*)arg;
    printf("线程%d (ID: %lu) 启动 - 使用return退出\n", 
           thread_id, pthread_self());
    
    for (int i = 0; i < 3; i++) {
        printf("线程%d工作: %d\n", thread_id, i);
        usleep(300000);
    }
    
    printf("线程%d通过return退出\n", thread_id);
    return (void*)(long)(thread_id * 100);
}

void* thread_func2(void* arg) {
    int thread_id = *(int*)arg;
    printf("线程%d (ID: %lu) 启动 - 使用pthread_exit退出\n", 
           thread_id, pthread_self());
    
    for (int i = 0; i < 3; i++) {
        printf("线程%d工作: %d\n", thread_id, i);
        usleep(200000);
    }
    
    printf("线程%d通过pthread_exit退出\n", thread_id);
    pthread_exit((void*)(long)(thread_id * 200));
}

void* thread_func3(void* arg) {
    int thread_id = *(int*)arg;
    printf("线程%d (ID: %lu) 启动 - 将被主线程取消\n", 
           thread_id, pthread_self());
    
    pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL);
    
    for (int i = 0; i < 3; i++) {
        printf("线程%d工作: %d (线程ID: %lu)\n", thread_id, i, pthread_self());
        usleep(400000);
        
        pthread_testcancel();
    }
    
    printf("线程%d正常结束（如果被取消，不会看到这条）\n", thread_id);
    return (void*)(long)(thread_id * 300);
}

int main() {
    pthread_t thread1, thread2, thread3;
    int id1 = 1, id2 = 2, id3 = 3;
    void *ret1, *ret2, *ret3;
    
    printf("主线程ID: %lu\n", pthread_self());
    printf("=== 开始创建线程 ===\n");
    
    pthread_create(&thread1, NULL, thread_func1, &id1);
    
    pthread_create(&thread2, NULL, thread_func2, &id2);
    
    pthread_create(&thread3, NULL, thread_func3, &id3);
    
    printf("=== 所有线程创建完成 ===\n");
    printf("线程1 ID: %lu\n", thread1);
    printf("线程2 ID: %lu\n", thread2);
    printf("线程3 ID: %lu\n", thread3);

    
    printf("\n主线程主动取消线程3...\n");
    pthread_cancel(thread3);
    
    pthread_join(thread1, &ret1);
    printf("线程1返回值: %ld\n", (long)ret1);
    
    pthread_join(thread2, &ret2);
    printf("线程2返回值: %ld\n", (long)ret2);
    
    pthread_join(thread3, &ret3);
    if (ret3 == PTHREAD_CANCELED) {
        printf("线程3: 被主线程取消终止 (PTHREAD_CANCELED)\n");
    } else {
        printf("线程3返回值: %ld\n", (long)ret3);
    }
    
    printf("\n=== 所有线程执行完成 ===\n");
    printf("主线程结束\n");
    
    return 0;
}