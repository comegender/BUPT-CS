#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

int main() {
    pid_t pid1, pid2;
    int status;
    
    printf("父进程PID: %d\n", getpid());
    
    if ((pid1 = fork()) == 0) {
        printf("子进程1 PID: %d, 父进程PID: %d\n", getpid(), getppid());
        
        char *args[] = {"ls", "-l", NULL};
        printf("子进程1调用exec执行ls -l命令:\n");
        execvp("ls", args);
        
        perror("exec失败");
        exit(1);
    } else if (pid1 > 0) {

        if ((pid2 = fork()) == 0) {
            printf("子进程2 PID: %d\n", getpid());
            
            for (int i = 0; i < 5; i++) {
                printf("子进程2正在工作...%d\n", i);
                sleep(2);
            }
            
            printf("子进程2正常退出\n");
            exit(10);
        } else if (pid2 > 0) {
            printf("父进程创建了两个子进程: %d 和 %d\n", pid1, pid2);
            
            sleep(8);
            printf("\n父进程尝试终止子进程2 (PID: %d)...\n", pid2);
            
            if (kill(pid2, SIGTERM) == 0) {
                printf("已向子进程2发送SIGTERM信号\n");
            } else {
                perror("kill失败");
            }
            
            pid_t finished_pid = wait(&status);
            if (finished_pid == pid1) {
                printf("子进程1 (PID: %d) 已结束\n", pid1);
            } else {
                if (WIFEXITED(status)) {
                    printf("子进程2 (PID: %d) 正常退出, 退出状态: %d\n", 
                           finished_pid, WEXITSTATUS(status));
                } else if (WIFSIGNALED(status)) {
                    printf("子进程2 (PID: %d) 被信号终止, 信号编号: %d\n", 
                           finished_pid, WTERMSIG(status));
                }
            }
            
            finished_pid = wait(&status);
            if (finished_pid == pid1) {
                printf("子进程1 (PID: %d) 已结束\n", pid1);
            } else {
                if (WIFEXITED(status)) {
                    printf("子进程2 (PID: %d) 正常退出, 退出状态: %d\n", 
                           finished_pid, WEXITSTATUS(status));
                } else if (WIFSIGNALED(status)) {
                    printf("子进程2 (PID: %d) 被信号终止, 信号编号: %d\n", 
                           finished_pid, WTERMSIG(status));
                }
            }
            
            printf("所有子进程已结束，父进程退出\n");
        } else {
            perror("第二个fork失败");
            exit(1);
        }
    } else {
        perror("第一个fork失败");
        exit(1);
    }
    
    return 0;
}