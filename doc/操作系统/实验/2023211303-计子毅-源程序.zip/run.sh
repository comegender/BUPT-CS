#!/bin/bash

echo "编译所有实验程序..."
gcc lab1.c -o lab1
gcc lab2.c -o lab2
gcc lab3.c -o lab3
gcc lab4.c -o lab4
gcc lab5.c -o lab5
gcc lab6-1.c -o lab6-1
gcc lab6-2.c -o lab6-2
gcc lab6-3.c -o lab6-3 
gcc lab6-4.c -o lab6-4 
gcc lab6-5.c -o lab6-5

echo "运行实验..."
echo -e "\n实验1 - 进程创建与管理:"
./lab1

echo -e "\n实验2 - 线程创建与管理:"
./lab2

echo -e "\n实验3 - 进程间通信:"
./lab3

echo -e "\n实验4 - 线程间通信:"
./lab4

echo -e "\n实验5 - 同步与互斥:"
./lab5

echo -e "\n实验6.1 - 检测CPU信息:"
./lab6-1

echo -e "\n实验6.2 - 基础并行对比:"
./lab6-2

echo -e "\n实验6.3 - 加锁vs不加锁:"
./lab6-3

echo -e "\n实验6.4 - Cache优化:"
./lab6-4

echo -e "\n实验6.5 - CPU 亲和力对并行程序影响:"
./lab6-5