#!/bin/bash

echo "=== 进程管理命令快速演示 ==="
echo ""

echo "1. ps命令演示:"
echo "当前进程:"
ps
echo ""

echo "2. top命令演示（快速显示）:"
top -bn1 | head -10
echo ""

echo "3. pstree命令演示:"
pstree | head -5
echo ""

echo "4. vmstat命令演示:"
vmstat 1 2
echo ""

echo "5. 创建测试进程用于演示:"
sleep 60 &
TEST_PID=$!
echo "创建sleep进程，PID: $TEST_PID"
echo ""

echo "6. jobs命令演示:"
jobs
echo ""

echo "7. kill命令演示:"
echo "终止测试进程..."
kill $TEST_PID
echo ""

echo "8. strace命令演示:"
strace -c echo "test" 2>&1 | head -5
echo ""

echo "9. ltrace命令演示:"
if command -v ltrace &> /dev/null; then
    ltrace echo "test" 2>&1 | head -5
else
    echo "ltrace未安装"
fi
echo ""

echo "10. sleep命令演示:"
echo "等待2秒..."
sleep 2
echo "等待结束"
echo ""

echo "=== 演示结束 ==="