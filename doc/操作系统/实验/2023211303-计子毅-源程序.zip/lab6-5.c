#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/time.h>

#define APPLE_MAX_VALUE 50000000

struct apple {
    unsigned long long a;
    char padding1[128];
    unsigned long long b;
    char padding2[128];
};

long long get_current_time() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (long long)tv.tv_sec * 1000000 + tv.tv_usec;
}

void* calc_apple(void* arg) {
    struct apple* test = (struct apple*)arg;
    for (unsigned long long sum = 0; sum < APPLE_MAX_VALUE; sum++) {
        test->a += sum;
    }
    return NULL;
}

void* calc_apple_b_no_lock(void* arg) {
    struct apple* test = (struct apple*)arg;
    for (unsigned long long sum = 0; sum < APPLE_MAX_VALUE; sum++) {
        test->b += sum;
    }
    return NULL;
}

void set_cpu_affinity(pthread_t thread, int cpu_id) {
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(cpu_id, &cpuset);
    
    int result = pthread_setaffinity_np(thread, sizeof(cpu_set_t), &cpuset);
    if (result != 0) {
        printf("设置CPU亲和性失败 (CPU %d)\n", cpu_id);
    }
}

void* no_affinity_test(void* arg) {
    struct apple* test = (struct apple*)malloc(sizeof(struct apple));
    test->a = 0;
    test->b = 0;
    
    pthread_t thread1, thread2;
    
    pthread_create(&thread1, NULL, calc_apple, test);
    pthread_create(&thread2, NULL, calc_apple_b_no_lock, test);
    
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    
    printf("无亲和性测试完成: a=%llu, b=%llu\n", test->a, test->b);
    free(test);
    return NULL;
}

void* with_affinity_test(void* arg) {
    struct apple* test = (struct apple*)malloc(sizeof(struct apple));
    test->a = 0;
    test->b = 0;
    
    pthread_t thread1, thread2;
    
    pthread_create(&thread1, NULL, calc_apple, test);
    pthread_create(&thread2, NULL, calc_apple_b_no_lock, test);
    
    set_cpu_affinity(thread1, 0);
    set_cpu_affinity(thread2, 1);
    
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    
    printf("有亲和性测试完成: a=%llu, b=%llu\n", test->a, test->b);
    free(test);
    return NULL;
}

void* single_thread_test(void* arg) {
    struct apple* test = (struct apple*)malloc(sizeof(struct apple));
    test->a = 0;
    test->b = 0;
    
    for (unsigned long long sum = 0; sum < APPLE_MAX_VALUE; sum++) {
        test->a += sum;
    }
    
    for (unsigned long long sum = 0; sum < APPLE_MAX_VALUE; sum++) {
        test->b += sum;
    }
    
    printf("单线程测试完成: a=%llu, b=%llu\n", test->a, test->b);
    free(test);
    return NULL;
}

int compare_long_long(const void* a, const void* b) {
    long long x = *(const long long*)a;
    long long y = *(const long long*)b;
    if (x < y) return -1;
    if (x > y) return 1;
    return 0;
}

long long calculate_k_best(long long* times, int count, int k) {
    qsort(times, count, sizeof(long long), compare_long_long);
    long long sum = 0;
    for (int i = 0; i < k; i++) {
        sum += times[i];
    }
    return sum / k;
}

void run_performance_test(const char* test_name, void* (*test_func)(void*), int iterations) {
    printf("\n=== 开始测试: %s ===\n", test_name);
    
    long long* times = (long long*)malloc(iterations * sizeof(long long));
    
    for (int i = 0; i < iterations; i++) {
        long long start_time = get_current_time();
        test_func(NULL);
        long long end_time = get_current_time();
        long long duration = end_time - start_time;
        
        times[i] = duration;
        
        printf("  第%d次运行时间: %lld 微秒\n", i+1, duration);
        
        usleep(100000);
    }
    
    long long k_best_time = calculate_k_best(times, iterations, iterations > 5 ? 5 : iterations);
    
    printf("=== %s 测试结果 ===\n", test_name);
    printf("最佳运行时间: %lld 微秒\n", times[0]);
    printf("平均运行时间: %lld 微秒\n", calculate_k_best(times, iterations, iterations));
    printf("K最佳运行时间: %lld 微秒\n", k_best_time);
    printf("==============================\n");
    
    free(times);
}

void show_cpu_info() {
    printf("=== 系统CPU信息 ===\n");
    system("lscpu | grep -E '(CPU\\(s\\)|Core\\(s\\)|Socket\\(s\\)|Thread\\(s\\))'");
    printf("=== CPU架构信息 ===\n");
    system("lscpu | grep -E '(Architecture|Model name|MHz)'");
    printf("==============================\n\n");
}

int main() {
    int iterations = 5;
    
    show_cpu_info();
    
    printf("开始CPU亲和性性能测试...\n");
    printf("每个测试将运行 %d 次，取最佳%d次的平均值\n\n", iterations,iterations);
    
    run_performance_test("单线程基准", single_thread_test, iterations);
    
    run_performance_test("无CPU亲和性(两线程)", no_affinity_test, iterations);

    run_performance_test("有CPU亲和性(两线程)", with_affinity_test, iterations);
    
    return 0;
}