#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>

#define NUM_THREADS 3

typedef struct {
    int count;
    char message[100];
    pthread_mutex_t mutex;
} shared_data_t;

shared_data_t shared_data;

void* writer_thread(void* arg) {
    int thread_id = *(int*)arg;
    
    for (int i = 0; i < 3; i++) {
        pthread_mutex_lock(&shared_data.mutex);
        
        shared_data.count++;
        sprintf(shared_data.message, "消息来自线程%d, 计数: %d", thread_id, shared_data.count);
        printf("线程%d写入: %s\n", thread_id, shared_data.message);
        
        pthread_mutex_unlock(&shared_data.mutex);
        usleep(200000);
    }
    
    return NULL;
}

void* reader_thread(void* arg) {
    int thread_id = *(int*)arg;
    
    for (int i = 0; i < 4; i++) {
        pthread_mutex_lock(&shared_data.mutex);
        
        printf("线程%d读取: 计数=%d, 消息=%s\n", 
               thread_id, shared_data.count, shared_data.message);
        
        pthread_mutex_unlock(&shared_data.mutex);
        usleep(300000);
    }
    
    return NULL;
}

int main() {
    pthread_t threads[NUM_THREADS];
    int thread_ids[NUM_THREADS] = {1, 2, 3};
    
    shared_data.count = 0;
    strcpy(shared_data.message, "初始消息");
    pthread_mutex_init(&shared_data.mutex, NULL);
    
    printf("主线程启动\n");
    printf("初始共享数据: 计数=%d, 消息=%s\n", shared_data.count, shared_data.message);

    if (pthread_create(&threads[0], NULL, writer_thread, &thread_ids[0]) != 0) {
        perror("创建写入线程失败");
        return 1;
    }
    
    if (pthread_create(&threads[1], NULL, reader_thread, &thread_ids[1]) != 0) {
        perror("创建读取线程1失败");
        return 1;
    }
    
    if (pthread_create(&threads[2], NULL, reader_thread, &thread_ids[2]) != 0) {
        perror("创建读取线程2失败");
        return 1;
    }

    // 主进程进行通信
    pthread_mutex_lock(&shared_data.mutex);
    shared_data.count*=2;
    sprintf(shared_data.message, "消息来自主线程%d, 计数: %d", getpid(), shared_data.count);
    printf("主线程%d写入: %s\n", getpid(), shared_data.message);
    pthread_mutex_unlock(&shared_data.mutex);
    usleep(300000);

    
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }
    
    printf("最终共享数据: 计数=%d, 消息=%s\n", shared_data.count, shared_data.message);
    
    pthread_mutex_destroy(&shared_data.mutex);
    printf("主线程结束\n");
    
    return 0;
}