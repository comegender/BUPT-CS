#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<vector>
#include<iomanip>
using namespace std;
#define N 700000

vector<pair<int, int>> v;
vector<pair<int, int>> temp_point;

int partition(vector<pair<int, int>> &v, int left, int right, int mode) {
    pair<int,int> temp = v[left];
    if (mode == 1) {
        while (left < right) {
            while (left < right && v[right].first >= temp.first) right--;
            v[left] = v[right];
            while (left < right && v[left].first <= temp.first) left++;
            v[right] = v[left];
        }
        v[left] = temp;
        return left;
    }
    else{
        while (left < right) {
            while (left < right && v[right].second >= temp.second) right--;
            v[left] = v[right];
            while (left < right && v[left].second <= temp.second) left++;
            v[right] = v[left];
        }
        v[left] = temp;
        return left;
    }

}

void sort_x(vector<pair<int, int>> &v, int left, int right) {
    if (left < right) {
        int pos = partition(v, left, right, 1);
        sort_x(v, left, pos - 1);
        sort_x(v, pos + 1, right);
    }
}

void sort_y(vector<pair<int, int>> &v, int left, int right) {
    if (left < right) {
        int pos = partition(v, left, right, 2);
        sort_x(v, left, pos - 1);
        sort_x(v, pos + 1, right);
    }
}

double distance(pair<int, int> p1, pair<int, int> p2) {
    return sqrt((p1.first - p2.first) * (p1.first - p2.first) + (p1.second - p2.second) * (p1.second - p2.second));
}

double min(double a, double b) {
    return a < b ? a : b;
}

double findPoint(int left, int right) {
    if (right - left == 1) return distance(v[left], v[right]);
    if (right - left == 2) {
        return min(distance(v[left], v[right]), min(distance(v[left], v[left + 1]), distance(v[left + 1], v[right])));
    }

    int mid = (left + right) / 2;
    double lmin = findPoint(left, mid);
    double rmin = findPoint(mid + 1, right);
    double minmin = min(lmin, rmin);
    for (int i = left; i <= right; i++) {
        if (v[i].first >= v[mid].first - minmin && v[i].first <= v[mid].first + minmin) {
            temp_point.push_back(v[i]);
        }
    }

    sort_y(temp_point, 0, temp_point.size() - 1);

    for (int i = 0; i < temp_point.size(); i++) {
        int k = 0;
        for (int j = i + 1; j < temp_point.size(); j++) {
            k++;
            if (temp_point[j].second - temp_point[i].second > minmin) break;
            double temp = distance(temp_point[j], temp_point[i]);
            minmin = min(temp, minmin);
            if (k == 6) break;
        }
    }
    return minmin;
}

int main() {
	ifstream ifs;
	ifs.open("point.in", ios::in);
	string line;
	int n;
	getline(ifs, line);
	istringstream iss;
	iss.str(line);
	iss >> n;
	while (getline(ifs, line)) {
		iss.clear();
		iss.str(line);
		int x, y;
		iss >> x >> y;
		pair<int, int> p(x, y);
		v.push_back(p);
	}
	ifs.close();
	ofstream ofs;
	ofs.open("point.out", ios::out);
    sort_x(v, 0, n - 1);
    double res = findPoint(0, n - 1);
    cout << fixed << setprecision(2) << res << endl;
    ofs << fixed << setprecision(2) << res;
    ofs.close();
	return 0;
}