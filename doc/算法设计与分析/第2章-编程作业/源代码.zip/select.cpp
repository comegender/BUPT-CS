#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
using namespace std;
#define N 800000

int partition(int* nums, int left, int right) {
	int x = nums[left];
	while (left < right) {
		while (left < right && nums[right] >= x) right--;
		nums[left] = nums[right];
		while (left < right && nums[left] <= x) left++;
		nums[right] = nums[left];
	}
	nums[left] = x;
	return left;
}

int find_k(int* nums, int left, int right, int k) {
	int pos = partition(nums, left, right);
	if (pos == k - 1) {
		return nums[pos];
	}
	else if (k - 1 < pos) find_k(nums, left, pos - 1, k);
	else find_k(nums, pos + 1, right, k);

	return -1;
}

int main() {
	ifstream ifs;
	ifs.open("select.in", ios::in);
	string line;
	int n, k;
	istringstream iss;
	getline(ifs, line);
	iss.str(line);
	iss >> n >> k;
	int* nums = new int[N];
	int a;
	while (getline(ifs, line)) {
		iss.clear();
		iss.str(line);
		for (int i = 0; i < n; i++) {
			iss >> a;
			nums[i] = a;
		}
	}
	ofstream ofs;
	ofs.open("select.out", ios::out);
	int res = find_k(nums, 0, n - 1, k);
	if (res != -1) ofs << res;
	else ofs << "error";
	ofs.close();
	return 0;
}