#include<iostream>
#include<string>
#include<fstream>
#include<sstream>
using namespace std;
#define N 1000000

void merge(int* nums, int left, int mid, int right) {
	int* b = new int[N];
	int i, j, k;
	for (int u = left; u <= right; u++) b[u] = nums[u];
	for (i = left, j = mid + 1, k = i; i <= mid && j <= right; k++) {
		if (b[i] <= b[j]) {
			nums[k] = b[i++];
		}
		else {
			nums[k] = b[j++];
		}
	}
	while (i <= mid) {
		nums[k++] = b[i++];
	}
	while (j <= right) {
		nums[k++] = b[j++];
	}
}

void mergesort(int* nums,int left,int right) {
	if (left < right) {
		int mid = (left + right) / 2;
		mergesort(nums, left, mid);
		mergesort(nums, mid + 1, right);
		merge(nums, left, mid, right);
	}
}

int main() {
	ifstream ifs;
	ofstream ofs;
	ifs.open("mergesort.in", ios::in);
	string line;
	int n;
	int* nums = new int[N];
	getline(ifs, line);
	n = line[0] - '0';
	int a;
	istringstream iss;
	while (getline(ifs, line)) {
		iss.str(line);
		for (int i = 0; i < n; i++) {
			iss >> a;
			nums[i] = a;
		}
	}
	mergesort(nums, 0, n - 1);
	ifs.close();
	ofs.open("mergesort.out", ios::out);
	for (int i = 0; i < n; i++) {
		ofs << nums[i] << " ";
	}
	ofs << endl;
	ofs.close();
	return 0;
}