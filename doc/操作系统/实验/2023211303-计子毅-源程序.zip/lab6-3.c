#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/time.h>

#define ORANGE_MAX_VALUE 1000000
#define APPLE_MAX_VALUE 100000000
#define MSECOND 1000000

struct apple {
    unsigned long long a;
    unsigned long long b;
    pthread_rwlock_t rwlock;
};

struct orange {
    int a[ORANGE_MAX_VALUE];
    int b[ORANGE_MAX_VALUE];
};

long long get_current_time() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (long long)tv.tv_sec * 1000000 + tv.tv_usec;
}

void* calc_apple(void* arg) {
    struct apple* test = (struct apple*)arg;
    for (unsigned long long sum = 0; sum < APPLE_MAX_VALUE; sum++) {
        test->a += sum;
    }
    return NULL;
}

void* calc_apple_b_lock(void* arg) {
    struct apple* test = (struct apple*)arg;
    for (unsigned long long sum = 0; sum < APPLE_MAX_VALUE; sum++) {
        pthread_rwlock_wrlock(&test->rwlock);
        test->b += sum;
        pthread_rwlock_unlock(&test->rwlock);
    }
    return NULL;
}

void* calc_apple_b_no_lock(void* arg) {
    struct apple* test = (struct apple*)arg;
    for (unsigned long long sum = 0; sum < APPLE_MAX_VALUE; sum++) {
        test->b += sum;
    }
    return NULL;
}

void* calc_orange(void* arg) {
    struct orange* test1 = (struct orange*)arg;
    unsigned long long sum = 0;
    for (int i = 0; i < ORANGE_MAX_VALUE; i++) {
        sum += test1->a[i] + test1->b[i];
    }
    return NULL;
}

void* three_thread_lock_test(void* arg) {
    struct apple* test = (struct apple*)malloc(sizeof(struct apple));
    struct orange* test1 = (struct orange*)malloc(sizeof(struct orange));
    
    test->a = 0;
    test->b = 0;
    pthread_rwlock_init(&test->rwlock, NULL);
    
    pthread_t thread_apple_a, thread_apple_b, thread_orange;
    
    pthread_create(&thread_apple_a, NULL, calc_apple, test);
    pthread_create(&thread_apple_b, NULL, calc_apple_b_lock, test);
    pthread_create(&thread_orange, NULL, calc_orange, test1);
    
    pthread_join(thread_apple_a, NULL);
    pthread_join(thread_apple_b, NULL);
    pthread_join(thread_orange, NULL);
    
    pthread_rwlock_destroy(&test->rwlock);
    free(test);
    free(test1);
    return NULL;
}

void* three_thread_no_lock_test(void* arg) {
    struct apple* test = (struct apple*)malloc(sizeof(struct apple));
    struct orange* test1 = (struct orange*)malloc(sizeof(struct orange));
    
    test->a = 0;
    test->b = 0;
    
    pthread_t thread_apple_a, thread_apple_b, thread_orange;
    
    pthread_create(&thread_apple_a, NULL, calc_apple, test);
    pthread_create(&thread_apple_b, NULL, calc_apple_b_no_lock, test);
    pthread_create(&thread_orange, NULL, calc_orange, test1);
    
    pthread_join(thread_apple_a, NULL);
    pthread_join(thread_apple_b, NULL);
    pthread_join(thread_orange, NULL);
    
    free(test);
    free(test1);
    return NULL;
}

int compare_long_long(const void* a, const void* b) {
    long long x = *(const long long*)a;
    long long y = *(const long long*)b;
    if (x < y) return -1;
    if (x > y) return 1;
    return 0;
}

long long calculate_k_best(long long* times, int count, int k) {
    qsort(times, count, sizeof(long long), compare_long_long);
    long long sum = 0;
    for (int i = 0; i < k; i++) {
        sum += times[i];
    }
    return sum / k;
}

void run_test(const char* test_name, void* (*test_func)(void*), int iterations) {
    printf("正在测试: %s\n", test_name);
    
    long long* times = (long long*)malloc(iterations * sizeof(long long));
    
    for (int i = 0; i < iterations; i++) {
        long long start_time = get_current_time();
        test_func(NULL);
        long long end_time = get_current_time();
        long long duration = end_time - start_time;
        
        times[i] = duration;
        
        printf("  第%d次运行时间: %lld 微秒\n", i+1, duration);
    }
    
    long long k_best_time = calculate_k_best(times, iterations, iterations > 5 ? 5 : iterations);
    
    printf("=== %s 测试结果 ===\n", test_name);
    printf("最佳运行时间: %lld 微秒\n", times[0]);
    printf("平均运行时间: %lld 微秒\n", calculate_k_best(times, iterations, iterations));
    printf("K最佳运行时间: %lld 微秒\n", k_best_time);
    printf("==============================\n\n");
    
    free(times);
}

int main() {
    int iterations = 5;
    
    printf("开始性能测试...\n\n");

    run_test("三线程加锁", three_thread_lock_test, iterations);
    
    run_test("三线程不加锁", three_thread_no_lock_test, iterations);
    
    return 0;
}