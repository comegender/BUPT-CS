#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define N 30    
#define M 3     

pthread_mutex_t mutex_p = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex_d = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t patient_cond = PTHREAD_COND_INITIALIZER;

typedef struct {
    int id;
    int state;
}patient;

patient Pstate[N];    
int wait_count = 0;      
int Dstate[M] = {0};
int treated_patients = 0;
int patient_id_counter = 0;

void* patient_thread(void* arg) {
    int id = *(int*)arg;
    
    pthread_mutex_lock(&mutex_p);
    
    if (patient_id_counter >= N) {
        printf("患者 %d: 号已满，离开医院\n", id);
        pthread_mutex_unlock(&mutex_p);
        return NULL;
    }
    
    patient tem;
    tem.id=id;
    tem.state=1;
    Pstate[patient_id_counter++] = tem;
    wait_count++;
    printf("患者 %d: 挂号成功，候诊中（当前候诊人数: %d）\n", id, wait_count);
    
    pthread_cond_signal(&patient_cond);
    pthread_mutex_unlock(&mutex_p);
    
    return NULL;
}

void* doctor_thread(void* arg) {
    int doctor_id = *(int*)arg;
    
    while (1) {
        pthread_mutex_lock(&mutex_d);
        
        while (wait_count == 0 || Dstate[doctor_id] == 1) {
            if (treated_patients >= N) {
                pthread_mutex_unlock(&mutex_d);
                return NULL;
            }
            pthread_cond_wait(&patient_cond, &mutex_d);
        }
        
        if (treated_patients >= N) {
            pthread_mutex_unlock(&mutex_d);
            break;
        }

        int patient_id,curp;

        pthread_mutex_lock(&mutex_p);
        for(int i=0;i<N;i++){
            if(Pstate[i].state==1){
                curp=i;
                patient_id=Pstate[i].id;
                Pstate[i].state=2;
                break;
            }
        }
        pthread_mutex_unlock(&mutex_p);
        
        wait_count--;
        
        Dstate[doctor_id] = 1;
        treated_patients++;
        
        printf("医生 %d: 开始治疗患者 %d（已治疗: %d/%d）\n", 
               doctor_id, patient_id, treated_patients, N);
        
        pthread_mutex_unlock(&mutex_d);
        
        usleep(200000);

        pthread_mutex_lock(&mutex_p);
        Pstate[curp].state=3;
        pthread_mutex_unlock(&mutex_p);

        pthread_mutex_lock(&mutex_d);
        Dstate[doctor_id] = 0;
        printf("医生 %d: 完成治疗患者 %d\n", doctor_id, patient_id);
        
        pthread_cond_signal(&patient_cond);
        pthread_mutex_unlock(&mutex_d);
        
        usleep(100000); 
    }
    
    return NULL;
}

int main() {
    pthread_t doctors[M];
    pthread_t patients[N + 5];
    
    int doctor_ids[M];
    int patient_ids[N + 5];
    
    for (int i = 0; i < M; i++) {
        doctor_ids[i] = i;
        pthread_create(&doctors[i], NULL, doctor_thread, &doctor_ids[i]);
    }
    
    for (int i = 0; i < N + 5; i++) {
        patient_ids[i] = i;
        pthread_create(&patients[i], NULL, patient_thread, &patient_ids[i]);
        usleep(50000);
    }
    
    for (int i = 0; i < N + 5; i++) {
        pthread_join(patients[i], NULL);
    }
    
    pthread_cond_broadcast(&patient_cond);
    
    for (int i = 0; i < M; i++) {
        pthread_join(doctors[i], NULL);
    }
    
    printf("\n=== 今日门诊结束 ===\n");
    printf("总治疗患者: %d/%d\n", treated_patients, N);
    printf("剩余候诊患者: %d\n", wait_count);
    
    pthread_mutex_destroy(&mutex_p);
    pthread_mutex_destroy(&mutex_d);
    pthread_cond_destroy(&patient_cond);
    
    return 0;
}